Plugins can be downloaded from :
- https://redirect.sonarsource.com/doc/plugin-library.html
